function i(n){return`${n.toLocaleString("vi-VN")}đ`}export{i as d};
