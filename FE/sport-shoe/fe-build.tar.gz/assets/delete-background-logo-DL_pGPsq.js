const o="/assets/delete-background-logo-CZeSPjbg.png";export{o as l};
