import{S as n}from"./sweetalert2.esm.all-0Z_61IYw.js";import{d as o}from"./dinhDangTien-Df4qCRL9.js";const r="#cf1018",x="#a90d14",d="sportshoe-alert-style";function u(){if(typeof document>"u"||document.getElementById(d))return;const t=document.createElement("style");t.id=d,t.textContent=`
    @keyframes sportshoeFadeIn {
      from {
        opacity: 0;
        transform: scale(0.92);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }
    
    @keyframes sportshoeFadeOut {
      from {
        opacity: 1;
        transform: scale(1);
      }
      to {
        opacity: 0;
        transform: scale(0.95);
      }
    }

    @keyframes sportshoeIconScale {
      from { transform: scale(0.4); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }

    .sportshoe-popup-show {
      animation: sportshoeFadeIn 0.25s cubic-bezier(0.34, 1.56, 0.64, 1) forwards !important;
    }

    .sportshoe-popup-hide {
      animation: sportshoeFadeOut 0.15s ease-out forwards !important;
    }

    .sportshoe-success-popup {
      width: min(430px, calc(100vw - 32px)) !important;
      padding: 34px 34px 28px !important;
      border-radius: 24px !important;
      border: 1px solid rgba(207, 16, 24, 0.16) !important;
      box-shadow: 0 24px 80px rgba(15, 23, 42, 0.22) !important;
    }

    .sportshoe-success-popup .swal2-icon {
      margin: 0 auto 18px !important;
      width: 82px !important;
      height: 82px !important;
      animation: sportshoeIconScale 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) both !important;
    }

    .sportshoe-success-popup .swal2-success-ring {
      border-color: rgba(207, 16, 24, 0.72) !important;
    }

    .sportshoe-success-popup .swal2-success-line-tip,
    .sportshoe-success-popup .swal2-success-line-long {
      background-color: ${r} !important;
    }

    .sportshoe-success-popup .swal2-success-circular-line-left,
    .sportshoe-success-popup .swal2-success-circular-line-right,
    .sportshoe-success-popup .swal2-success-fix {
      display: none !important;
    }

    .sportshoe-success-title {
      margin: 0 !important;
      color: ${x} !important;
      font-size: 28px !important;
      font-weight: 800 !important;
      line-height: 1.2 !important;
      letter-spacing: 0 !important;
    }

    .sportshoe-success-text {
      margin: 14px auto 0 !important;
      max-width: 330px !important;
      color: #475569 !important;
      font-size: 18px !important;
      font-weight: 500 !important;
      line-height: 1.45 !important;
    }

    .sportshoe-success-progress {
      background: linear-gradient(90deg, ${r}, #ff6a00) !important;
      height: 4px !important;
    }

    .sportshoe-error-progress {
      background: #cbd5e1 !important;
      height: 4px !important;
    }
  `,document.head.appendChild(t)}const p=n.mixin({toast:!0,position:"top-end",showConfirmButton:!1,timerProgressBar:!0,customClass:{popup:"rounded-2xl shadow-xl border-0 pr-4",title:"text-sm font-semibold text-slate-800",htmlContainer:"text-xs text-slate-500",timerProgressBar:"bg-rose-400"}}),g=n.mixin({customClass:{popup:"rounded-[32px] p-4 shadow-xl border-0",title:"text-xl font-bold text-slate-800",htmlContainer:"text-sm text-slate-500 font-medium",confirmButton:"bg-[#cf1018] text-white px-8 py-2.5 rounded-full font-semibold hover:bg-rose-700 transition focus:ring-4 focus:ring-rose-100",cancelButton:"bg-slate-100 text-slate-700 px-8 py-2.5 rounded-full font-semibold hover:bg-slate-200 transition focus:ring-4 focus:ring-slate-200",actions:"gap-4 mt-6",icon:"border-0"},iconColor:r,buttonsStyling:!1});function l(t){const e=String(t||"").trim();return e?e.toLowerCase()==="thành công"?"Thành công!":e:"Thành công!"}function v(t="",e="Thành công!"){return p.fire({icon:"success",title:l(e),text:t||void 0,timer:2e3,iconColor:r,target:document.getElementById("pos-tablet-screen")||"body"})}function y(t="",e="Thất bại!"){return u(),n.fire({icon:"error",title:e,text:t||void 0,toast:!1,position:"center",showConfirmButton:!1,timer:3500,timerProgressBar:!0,background:"#ffffff",color:"#334155",iconColor:r,target:document.getElementById("pos-tablet-screen")||"body",showClass:{popup:"sportshoe-popup-show",backdrop:"swal2-noanimation"},hideClass:{popup:"sportshoe-popup-hide",backdrop:"swal2-noanimation"},customClass:{popup:"sportshoe-success-popup",title:"sportshoe-success-title",htmlContainer:"sportshoe-success-text",timerProgressBar:"sportshoe-error-progress"}})}function B(t="",e="Thành công!"){return u(),n.fire({icon:"success",title:l(e),html:t||void 0,toast:!1,position:"center",showConfirmButton:!1,timer:2600,timerProgressBar:!0,background:"#ffffff",color:"#334155",iconColor:"#16a34a",target:document.getElementById("pos-tablet-screen")||"body",showClass:{popup:"sportshoe-popup-show",backdrop:"swal2-noanimation"},hideClass:{popup:"sportshoe-popup-hide",backdrop:"swal2-noanimation"},customClass:{popup:"sportshoe-success-popup",title:"sportshoe-success-title",htmlContainer:"sportshoe-success-text",timerProgressBar:"sportshoe-success-progress"}})}function C(t="",e="Thành công!"){return p.fire({icon:"success",title:l(e),text:t||void 0,timer:2e3,iconColor:r,target:document.getElementById("pos-tablet-screen")||"body"})}function k(t="",e="Thông báo"){return p.fire({icon:"warning",title:e,text:t||void 0,timer:4e3,iconColor:"#f59e0b",target:document.getElementById("pos-tablet-screen")||"body"})}async function T(t,e="Xác nhận",i="Đồng ý",s="Hủy"){return(await g.fire({title:e,html:t,icon:"question",showCancelButton:!0,confirmButtonText:i,cancelButtonText:s,reverseButtons:!0,focusConfirm:!1,target:document.getElementById("pos-tablet-screen")||"body"})).isConfirmed}async function S({oldCouponCode:t,newCouponCode:e,oldDiscount:i,newDiscount:s,tongTienHang:a}){const m=s-i,f=a-s,h=`
    <div class="text-left font-sans text-slate-800">
      <div class="bg-red-50 border border-red-100 rounded-lg p-3 mb-5 flex items-center gap-2">
        <svg class="w-5 h-5 text-[#cf1018] flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
        <span class="text-[#a90d14] font-medium text-[15px]">${t?"Có voucher tốt hơn cho đơn hàng của bạn!":"Có voucher giảm giá cho đơn hàng của bạn!"}</span>
      </div>

      <div class="grid grid-cols-2 gap-4 mb-5">
        <div>
          <div class="text-sm text-slate-500 mb-1.5 font-medium">Voucher hiện tại</div>
          ${t?`<div class="inline-block px-2.5 py-1 bg-blue-50 text-blue-600 border border-blue-100 rounded-md text-sm font-semibold mb-2">${t}</div>`:'<div class="text-sm text-slate-400 mb-2 italic">Chưa áp dụng</div>'}
          <div class="text-sm text-slate-600 flex items-center gap-1">Giảm: <span class="${i>0?"line-through text-slate-400":""}">${o(i)}</span></div>
        </div>
        <div>
          <div class="text-sm text-[#cf1018] mb-1.5 font-medium">Voucher mới</div>
          <div class="inline-block px-2.5 py-1 bg-red-50 text-[#cf1018] border border-red-100 rounded-md text-sm font-semibold mb-2">${e}</div>
          <div class="text-sm text-[#cf1018] font-medium">Giảm: ${o(s)}</div>
        </div>
      </div>

      <div class="bg-red-50 rounded-lg p-3 mb-5 flex justify-between items-center">
        <span class="text-slate-700 font-semibold text-[15px]">Bạn tiết kiệm thêm:</span>
        <span class="text-[#cf1018] font-bold text-[15px]">+${o(m)}</span>
      </div>

      <div class="border-t border-slate-100 pt-4 mb-2">
        <div class="flex justify-between items-center mb-2.5">
          <span class="text-slate-500 text-[15px]">Tổng tiền hàng:</span>
          <span class="text-slate-700 font-medium">${o(a)}</span>
        </div>
        <div class="flex justify-between items-center mb-4">
          <span class="text-slate-500 text-[15px]">Giảm giá:</span>
          <span class="text-[#cf1018] font-medium">-${o(s)}</span>
        </div>
        <div class="flex justify-between items-center pt-3 border-t border-slate-100">
          <span class="text-slate-800 font-semibold text-[15px]">Tổng thanh toán:</span>
          <span class="text-[#cf1018] font-bold text-lg">${o(f)}</span>
        </div>
      </div>
    </div>
  `,c=await n.fire({title:'<div class="flex items-center gap-2"><div class="w-7 h-7 rounded-full bg-[#cf1018] text-white flex items-center justify-center font-bold text-[15px]">i</div> <span class="text-lg">Có voucher tốt hơn</span></div>',html:h,showCancelButton:!0,showDenyButton:!1,showCloseButton:!0,confirmButtonText:"Dùng voucher mới (tiết kiệm hơn)",cancelButtonText:t?"Giữ voucher cũ":"Không dùng voucher",customClass:{popup:"rounded-xl p-5 shadow-2xl border-0 w-full max-w-[480px]",title:"text-xl font-bold text-slate-800 m-0 text-left border-0 w-full flex items-center",htmlContainer:"m-0 mt-5",confirmButton:"bg-[#cf1018] text-white px-4 py-2 rounded text-[15px] font-medium hover:bg-[#a90d14] transition order-2",cancelButton:"bg-white text-slate-600 border border-slate-200 px-4 py-2 rounded text-[15px] font-medium hover:bg-slate-50 transition order-1",actions:"gap-3 mt-6 justify-end w-full flex-nowrap",closeButton:"focus:outline-none mt-2 mr-2 bg-slate-100 hover:bg-slate-200 rounded text-slate-500 hover:text-slate-700 transition"},target:document.getElementById("pos-tablet-screen")||"body",buttonsStyling:!1});return c.isConfirmed?"use_new":c.isDismissed&&c.dismiss===n.DismissReason.cancel?"use_old":"cancel"}export{y as a,k as b,T as c,B as d,C as e,S as f,v as s,p as t};
