function s(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function r(e,o="td"){return`<${o} style="border:1px solid #dbeafe;padding:8px 12px;text-align:left;vertical-align:top;">${s(e)}</${o}>`}function x({filename:e,sheetName:o="Sheet1",columns:l=[],rows:a=[]}){if(!a.length||!l.length)return!1;const d=`<tr>${l.map(n=>r(n.label,"th")).join("")}</tr>`,i=a.map((n,h)=>`<tr>${l.map(c=>{const u=typeof c.value=="function"?c.value(n,h):n?.[c.key];return r(u)}).join("")}</tr>`).join(""),p=`
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
      <head>
        <meta charset="UTF-8" />
        <meta name="ProgId" content="Excel.Sheet" />
        <meta name="Generator" content="Codex" />
        <title>${s(o)}</title>
      </head>
      <body>
        <table>
          ${d}
          ${i}
        </table>
      </body>
    </html>
  `,f=new Blob([`\uFEFF${p}`],{type:"application/vnd.ms-excel;charset=utf-8;"}),t=document.createElement("a"),m=e.endsWith(".xls")?e:`${e}.xls`;return t.href=URL.createObjectURL(f),t.download=m,document.body.appendChild(t),t.click(),document.body.removeChild(t),URL.revokeObjectURL(t.href),!0}export{x as e};
